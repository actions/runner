

# ![osx](../res/apple_med.png) macOS/OS X System Prerequisites

## Supported Versions

  - macOS High Sierra (10.13) and later versions


## [More .Net Core Prerequisites Information](https://docs.microsoft.com/en-us/dotnet/core/macos-prerequisites?tabs=netcore30)
