﻿using System;

namespace GitHub.DistributedTask.WebApi
{
    public static class WellKnownServiceEndpointNames
    {
        public const String SystemVssConnection = "SystemVssConnection";
    }
}
