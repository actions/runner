var formidable = require("formidable");
var http = require("http");
var https = require("https");
var path = require("path");
const fs = require("fs");
const del = require("del");
const tasklib = require("azure-pipelines-task-lib");

try {
    var submodules = false;
    var nestedSubmodules = false;
    var repository = tasklib.getInput("repository");
    var ref = tasklib.getInput("ref");
    var destpath = tasklib.getInput("path");
    var submodulesInput = tasklib.getInput("submodules");
    if(submodulesInput === "true") {
    	submodules = true;
    }
    if(submodulesInput === "recursive") {
    	submodules = true;
    	nestedSubmodules = true;
    }
    const url = tasklib.getEndpointUrlRequired("SYSTEMVSSCONNECTION") + "_apis/v1/Message/multipart/" + tasklib.getVariable("System.RunId") + "?submodules=" + (submodules ? "true" : "false") + "&nestedSubmodules=" + (nestedSubmodules ? "true" : "false") + (repository && ref ? "&repositoryAndRef=" + encodeURIComponent(repository + "@" + ref) : "");
    tasklib.debug(url);
    const dest = destpath ? (process.cwd() + "/" + destpath) : process.cwd();
    var clean = tasklib.getInput("clean");
    if(clean === undefined || clean === "" || clean === "true") {
        var posixdest = dest.replace(/\\/g, "/");
        console.log("Clean folder: " + dest);
        del.sync([ posixdest + "/**", "!" + posixdest ]);
    }
    console.log("Copying Repository to " + dest);

    var form = formidable({
        uploadDir: dest,
        maxFileSize: 1024 * 1024 * 1024 * 1024
    });
    (url.startsWith("https://") ? https.get : http.get)(url, res => {
        var _first = true;
        var symlinks = [];
        form.parse(res, (err, fields, files) => {
            tasklib.debug("Creating Symlinks");
            while(true) {
                var dsymlinks = [];
                for(var lnk of symlinks) {
                    if(fs.existsSync(path.join(path.dirname(lnk.path), lnk.value))) {
                        tasklib.debug("path=`" + lnk.path + "` => `" + lnk.value + "`");
                        try {
                            fs.symlinkSync(lnk.value, lnk.path);
                        } catch {
                            tasklib.warning("Failed to create symlink `" + lnk.path + "` to `" + lnk.value + "`");
                        }
                    } else {
                        tasklib.debug("Delay restoring symlink path=`" + lnk.path + "` => `" + lnk.value + "`");
                        dsymlinks.push(lnk);
                    }
                }
                if(symlinks.length === dsymlinks.length) {
                    tasklib.debug("Creating dead Symlinks");
                    for(var lnk of symlinks) {
                        tasklib.debug("path=`" + lnk.path + "` => `" + lnk.value + "`");
                        try {
                            fs.symlinkSync(lnk.value, lnk.path);
                        } catch {
                            tasklib.warning("Failed to create symlink `" + lnk.path + "` to `" + lnk.value + "`");
                        }
                    }
                    break;
                }
                symlinks = dsymlinks;
            }
            tasklib.debug("Finished creating Symlinks");
        }).on("fileBegin", (formname, file) => {
            if(formname == null && _first) {
                tasklib.warning("No files found to copy to " + dest);
                process.exit();
            }
            _first = false;
            if(formname.startsWith("=?utf-8?B?")) {
                formname = Buffer.from(formname.substring("=?utf-8?B?".length), "base64").toString("utf-8");
            }
            var modeend = formname.indexOf(":");
            if(modeend !== -1) {
                formname = formname.substr(modeend + 1);
            }
            file.filename = path.join(dest, formname);
            file.path = path.join(dest, formname);
            fs.mkdirSync(path.dirname(file.path), { recursive: true });
        }).on("file", (formname, file) => {
            if(formname.startsWith("=?utf-8?B?")) {
                formname = Buffer.from(formname.substring("=?utf-8?B?".length), "base64").toString("utf-8");
            }
            var modeend = formname.indexOf(":");
            var mode = "644";
            if(modeend != -1) {
                mode = formname.substr(0, modeend);
                formname = formname.substr(modeend + 1);
            }
            try {
                fs.chmodSync(file.path, mode);
            } catch {
                tasklib.warning("Failed to set mode of `" + file.path + "` to " + mode);
            }
            tasklib.debug(formname + ", mode=" + mode + " => " + file.path);
        }).on("field", (formname, value) => {
            if(formname.startsWith("=?utf-8?B?")) {
                formname = Buffer.from(formname.substring("=?utf-8?B?".length), "base64").toString("utf-8");
            }
            var modeend = formname.indexOf(":");
            var mode = "644";
            if(modeend != -1) {
                mode = formname.substr(0, modeend);
                formname = formname.substr(modeend + 1);
            }
            if(mode === "lnk") {
                try {
                    destpath = path.join(dest, formname);
                    fs.mkdirSync(path.dirname(destpath), { recursive: true });
                    symlinks.push({path: path.join(dest, formname), value: value});
                } catch {
                    tasklib.warning("Failed to create directory for symlink `" + path.join(dest, formname) + "` to `" + value + "`");
                }
            } else {
                tasklib.warning("Expected mode lnk, ignore entry `" + formname + "`");
            }
            tasklib.debug(formname + ", mode=" + mode + " => " + value);
        });
    });
} catch (error) {
    tasklib.error(error.message);
    process.exit(1);
}
